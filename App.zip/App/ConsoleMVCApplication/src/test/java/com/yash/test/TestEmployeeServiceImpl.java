package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.dao.EmployeesDAO;
import com.yash.dao.JDBCEmployeesDAOImpl;
import com.yash.entity.Employees;
import com.yash.exception.EmployeesDAOException;
import com.yash.model.EmployeesModel;
import com.yash.service.EmployeeServiceImpl;

class TestEmployeeServiceImpl {

	@Spy
	private JDBCEmployeesDAOImpl employeesDAO;
	@InjectMocks
	private EmployeeServiceImpl employeeServiceImpl;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testpersistEmployee_positive() {

		Employees employees=new Employees();
		employees.setEmpId(1006);
		employees.setEmpName("rohan");
		employees.setEmpSalary(45000);
		employees.setEmpDesignation("Programmer");
		/*
		
		try {
			when(employeesDAO.storeEmployees(employees)).thenAnswer((invocation)->{
				Employees employeesParam=invocation.getArgumentAt(0, Employees.class);
				if(employeesParam.getEmpId()==1006) {
					return true;
				}else {
					return false;
				}
			});
		} catch (EmployeesDAOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		/*try {
			when(employeesDAO.storeEmployees(employees)).thenAnswer(
					new Answer<Boolean>() {
						public Boolean answer(InvocationOnMock invocation) throws Throwable{
							Employees employees=invocation.getArgumentAt(0, Employees.class);
							Object[] arguments=invocation.getArguments();
							if(employees.getEmpId()==1006) {
								return true;
							}else {
								return false;
							}
						}
					}
					);
			*/
		//try {
			EmployeesModel employeesModel=new EmployeesModel();
			employeesModel.setEmpId(1006);
			employeesModel.setEmpName("rohan");
			employeesModel.setEmpSalary(45000);
			employeesModel.setEmpDesignation("Programmer");
			
			boolean expected=true;
			boolean actual=employeeServiceImpl.persistEmployee(employeesModel);
			assertEquals(expected,actual);
		/*} catch (EmployeesDAOException e) {
			// TODO Auto-generated catch block
           assertTrue(false);
		}*/
	}

}
