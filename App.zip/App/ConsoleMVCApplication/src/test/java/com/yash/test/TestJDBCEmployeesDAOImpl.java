package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.dao.JDBCEmployeesDAOImpl;
import com.yash.entity.Employees;
import com.yash.exception.EmployeesDAOException;
import com.yash.helper.ConnectionManager;

class TestJDBCEmployeesDAOImpl {

	@Mock
	private ConnectionManager manager;
	@Mock
	private Connection connection;
	@Mock
	private Statement statement;
	@Mock
	private PreparedStatement preparedStatement;
	
	@Mock
	private ResultSet resultSet;
	
	@InjectMocks
	private JDBCEmployeesDAOImpl jdbcEmployeesDAOImpl;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	@Test
	void testGetAllEmployees_Positive() {
   
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.createStatement()).thenReturn(statement);
			when(statement.executeQuery(anyString())).thenReturn(resultSet);
			when(resultSet.next()).thenReturn(true).thenReturn(false);
			List<Employees> employeesList=jdbcEmployeesDAOImpl.getAllEmployees();
			assertTrue(employeesList.size()>0);
			
		} catch (ClassNotFoundException e) {
		 assertTrue(false);
		} catch (SQLException e) {
		 assertTrue(false);

		} catch (EmployeesDAOException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}

	
	}
	@Test
	void testGetAllEmployees_negative() {
   
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.createStatement()).thenReturn(statement);
			when(statement.executeQuery(anyString())).thenReturn(resultSet);
			when(resultSet.next()).thenReturn(false);
			List<Employees> employeesList=jdbcEmployeesDAOImpl.getAllEmployees();
			assertTrue(employeesList.size()==0);
			
		} catch (ClassNotFoundException e) {
		 assertTrue(false);
		} catch (SQLException e) {
		 assertTrue(false);

		} catch (EmployeesDAOException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}
	}
	@Test
	void testGetAllEmployees_exception() {
   
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.createStatement()).thenReturn(statement);
			when(statement.executeQuery(anyString())).thenThrow(SQLException.class);
			when(resultSet.next()).thenReturn(false);
			List<Employees> employeesList=jdbcEmployeesDAOImpl.getAllEmployees();			
		} catch (ClassNotFoundException e) {
		 assertTrue(false);
		} catch (SQLException e) {
		 assertTrue(true);
		} catch (EmployeesDAOException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}
	}

	@Test
	void testupdateEmployees_Positive() {
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
			when(preparedStatement.executeUpdate()).thenReturn(1);
			boolean expected=true;
			boolean actual=jdbcEmployeesDAOImpl.updateEmployees(1001, 85000);
			assertEquals(expected,actual);
		} catch (ClassNotFoundException | SQLException | EmployeesDAOException e) {
			// TODO Auto-generated catch block
          assertTrue(false);
		}
		
	}
	@Test
	void testupdateEmployees_Negative() {
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
			when(preparedStatement.executeUpdate()).thenReturn(0);
			boolean expected=false;
			boolean actual=jdbcEmployeesDAOImpl.updateEmployees(999, 85000);
			assertEquals(expected,actual);
		} catch (ClassNotFoundException | SQLException | EmployeesDAOException e) {
			// TODO Auto-generated catch block
          assertTrue(false);
		}	
	}
	@Test
	void testupdateEmployees_Exception() {
		try {
			when(manager.openConnection()).thenReturn(connection);
			when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
			when(preparedStatement.executeUpdate()).thenThrow(SQLException.class);
			jdbcEmployeesDAOImpl.updateEmployees(999, 85000);
		} catch (ClassNotFoundException | SQLException | EmployeesDAOException e) {
			// TODO Auto-generated catch block
          assertTrue(true);
		}	
	}
	
}
