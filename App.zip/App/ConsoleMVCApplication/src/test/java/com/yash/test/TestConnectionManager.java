package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.helper.ConnectionManager;
import com.yash.helper.DataSource;

class TestConnectionManager {

	@InjectMocks
	private ConnectionManager manager;
	
	@Mock
	private DataSource dataSource;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testOpenConnection_Positive() {
		
		when(dataSource.getDriver()).thenAnswer(
				new Answer<String>() {
					public String answer(InvocationOnMock invocation) throws Throwable {
						return "com.mysql.jdbc.Driver";
					}
				}
				);
	
		when(dataSource.getUrl()).thenAnswer(
				new Answer<String>() {
					public String answer(InvocationOnMock invocation) throws Throwable {
						return "jdbc:mysql://localhost:3306/test";
					}
				}
				);
		
		when(dataSource.getUsername()).thenAnswer(
				new Answer<String>() {
					public String answer(InvocationOnMock invocation) throws Throwable {
						return "root";
					}
				}
				);
		when(dataSource.getPassword()).thenAnswer(
				new Answer<String>() {
					public String answer(InvocationOnMock invocation) throws Throwable {
						return "root";
					}
				}
				);
		
		try {
			Connection connection=manager.openConnection();
			assertTrue(connection!=null);
		} catch (ClassNotFoundException e) {
        assertTrue(false);
		} catch (SQLException e) {
	     assertTrue(false);
		}
	
	}

}
