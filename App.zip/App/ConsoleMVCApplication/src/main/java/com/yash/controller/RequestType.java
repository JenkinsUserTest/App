package com.yash.controller;

public enum RequestType {
	
	RETRIEVE(1),RETREIVEBYID(2),INSERT(3),UPDATE(4),DELETE(5);
	int val;
	private RequestType(int val) {
		this.val=val;
	}
	public int getVal() {
		return val;
	}

}
