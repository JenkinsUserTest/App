package com.yash.client;


import com.yash.view.EmployeeView;

public class EmployeeClient {

	public static void main(String[] args) {

		EmployeeView employeeView=new EmployeeView();
		employeeView.mainMenu();
		
	}

}
