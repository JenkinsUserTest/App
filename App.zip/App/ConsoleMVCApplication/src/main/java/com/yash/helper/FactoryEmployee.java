package com.yash.helper;

import com.yash.dao.EmployeesDAO;
import com.yash.dao.JDBCEmployeesDAOImpl;
import com.yash.exception.EmployeesDAOException;
import com.yash.service.EmployeeService;
import com.yash.service.EmployeeServiceImpl;

public class FactoryEmployee {
	private static EmployeesDAO employeesDAO=null;
	private static EmployeeService employeeService=null;
	public static EmployeesDAO createEmployeeDAO() {
		try {
			employeesDAO=new JDBCEmployeesDAOImpl();
		} catch (EmployeesDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employeesDAO;
	}
	
	public static EmployeeService createEmployeeService() {
		employeeService=new EmployeeServiceImpl();
		return employeeService;
		
	}

}
