package com.yash.view;

import java.util.List;
import java.util.Scanner;

import com.yash.controller.EmployeeController;
import com.yash.controller.RequestType;
import com.yash.model.EmployeesModel;

public class EmployeeView {

	public void mainMenu() {
		System.out.println("1. View All Employees:\n");
		System.out.println("2. View  Employee by Id:\n");
		System.out.println("3. Register Employee\n");
		System.out.println("4. Update Employee\n");
		System.out.println("5. Delete Employee\n");
		System.out.println("6. Exit");
		Scanner scanner=new Scanner(System.in);
		System.out.print("Please Enter option:");
		EmployeeController controller=new EmployeeController();

		if(scanner.hasNextInt()) {
			int option=scanner.nextInt();
			switch(option) {
			case 1:
				   controller.handleRequest(RequestType.RETRIEVE);
				   break;
			case 2:
				   controller.handleRequest(RequestType.RETREIVEBYID);
				   break;
			case 3:
				  controller.handleRequest(RequestType.INSERT);
				  break;
			case 4:
				  controller.handleRequest(RequestType.UPDATE);
				  break;
			case 5:
				  controller.handleRequest(RequestType.DELETE);
				  break;
			case 6:
				System.exit(0);
				break;
			}
		}
	}

	
	public void retrieveEmployeeById() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Please Enter Employee Id:");
		int empId=0;
		
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
		EmployeeController controller=new EmployeeController();

		controller.displayEmployeeById(empId);
		
		
	}
	
	public void registerEmployee() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
		System.out.print("Employee Name:");
		String empName="";
		if(scanner.hasNext()) {
			empName=scanner.next();
		}
		double empSalary=0.0;
		System.out.print("Employee Salary:");

		if(scanner.hasNextDouble()) {
			empSalary=scanner.nextDouble();
		}
		String empDesignation="";
		System.out.print("Employee Designation:");

		if(scanner.hasNext()) {
			empDesignation=scanner.next();
		}
		
		EmployeesModel model=new EmployeesModel();
		model.setEmpId(empId);
		model.setEmpName(empName);
		model.setEmpSalary(empSalary);
		model.setEmpDesignation(empDesignation);
		EmployeeController controller=new EmployeeController();
		controller.registerEmployee(model);
		
	}
	
	public void deleteEmployee() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
			
	
		EmployeeController controller=new EmployeeController();
		controller.deleteEmployee(empId);
		
	}
	
	public void success(String message) {
		System.out.println(message);
	}
	public void failed(String message) {
		System.out.println(message);
	}
	
	public void updateEmployee() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
	
		double empSalary=0.0;
		System.out.print("Employee New Salary:");

		if(scanner.hasNextDouble()) {
			empSalary=scanner.nextDouble();
		}
	
		
	
		EmployeeController controller=new EmployeeController();
		controller.updateEmployeeSalary(empId,empSalary);
		
	}
	public void displayAllEmployees(List<EmployeesModel> employeesModelList) {
		
		for(EmployeesModel model:employeesModelList) {
			System.out.println(model);
		}
	}
	public void displayEmployee(EmployeesModel model) {
		System.out.println(model);
	}
	

}
