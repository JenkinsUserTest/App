package com.yash.controller;

import java.util.List;

import com.yash.helper.FactoryEmployee;
import com.yash.model.EmployeesModel;
import com.yash.service.EmployeeService;
import com.yash.view.EmployeeView;

public class EmployeeController {
	
	private EmployeeService employeeService;
	
	public EmployeeController() {
		this.employeeService=FactoryEmployee.createEmployeeService();
	}
	EmployeeView employeeView=new EmployeeView();
	public void handleRequest(RequestType type) {
		
		switch(type) {
		
		case RETRIEVE:
		             List<EmployeesModel> employeeModelList=employeeService.getAllEmployees();
		             employeeView.displayAllEmployees(employeeModelList);
		             break;
		case RETREIVEBYID:
			            employeeView.retrieveEmployeeById();
			            break;
		case INSERT:
			            employeeView.registerEmployee();
			            break;
		case UPDATE:
			           employeeView.updateEmployee();
			           break;
		case DELETE:
			         employeeView.deleteEmployee();
			         break;
		
		}
	}
	
	public void deleteEmployee(int empId) {
		boolean result=employeeService.deleteEmployee(empId);
		if(result) {
			employeeView.success("Record successfully deleted");
		}else {
			employeeView.failed("Record deletion failed");
		}
	}
	
	public void updateEmployeeSalary(int empId,double empSalary) {
		boolean result=employeeService.UpdateEmployeeSalary(empId, empSalary);
		if(result) {
			employeeView.success("Record successfully updated");
		}else {
			employeeView.failed("Record updation failed");
		}
	}
	public void displayEmployeeById(int empId) {
		EmployeesModel employeesModel=employeeService.getEmployeeById(empId);
		employeeView.displayEmployee(employeesModel);
		
	}
	
	public void registerEmployee(EmployeesModel model) {
		boolean result=employeeService.persistEmployee(model);
		if(result) {
			employeeView.success("Registration was successful");
		}else {
			employeeView.failed("Registration failed");
		}
	}

}
