package com.yash.service;

import java.util.List;

import com.yash.entity.Employees;
import com.yash.model.EmployeesModel;

public interface EmployeeService {
	public List<EmployeesModel> getAllEmployees();
	public EmployeesModel getEmployeeById(int empId);
	public boolean persistEmployee(EmployeesModel employee);
	public boolean UpdateEmployeeSalary(int empId, double newSalary);
	public boolean deleteEmployee(int empId);

}
